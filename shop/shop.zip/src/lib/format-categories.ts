export const formatCategories = () => {};
