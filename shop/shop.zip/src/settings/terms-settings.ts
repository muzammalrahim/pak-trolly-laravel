export const termsAndServices = [
  {
    id: "1",
    title: "terms-one-title",
    description:"terms-one-content",
  },
  {
    id: "2",
    title: "terms-two-title",
    description: "terms-two-content",
  },
  {
    id: "3",
    title: "terms-three-title",
    description:"terms-three-content",
  },
  {
    id: "4",
    title: "terms-four-title",
    description:"terms-four-content",
  },
  {
    id: "5",
    title: "terms-five-title",
    description:"terms-five-content",
  },
  {
    id: "6",
    title: "terms-six-title",
    description:"terms-six-content",
  },
];
