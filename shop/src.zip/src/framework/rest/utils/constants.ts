export enum AddressType {
  Billing = 'billing',
  Shipping = 'shipping',
}
