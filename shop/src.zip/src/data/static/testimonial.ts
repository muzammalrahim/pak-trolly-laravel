export const testimonials = [
	{
		id: 1,
		avatar: {
			src: "/assets/images/testimonials/1.jpg",
			width: 420,
			height: 420,
		},
		rating: 4,
		name: "Perry White",
		text: "Best services i ever have. Product Quality was so good. Love it",
	},
	{
		id: 2,
		avatar: {
			src: "/assets/images/testimonials/2.jpg",
			width: 420,
			height: 420,
		},
		rating: 3,
		name: "Jiniya Snow",
		text: "I highly recommend Pak Trolly Website for online Electronic Shopping..Very Reliable, Trustworthy and On-time Delivery",
	},
	{
		id: 3,
		avatar: {
			src: "/assets/images/testimonials/3.jpg",
			width: 420,
			height: 420,
		},
		rating: 5,
		name: "Ketty Rawn",
		text: "Delevry time is good. My orders product was up-to-mark in quality..Whatever i ordered it was same as in images.Higly recommanded if you want anything good, only order from Pak Trolly.",
	},
	{
		id: 4,
		avatar: {
			src: "/assets/images/testimonials/4.jpg",
			width: 420,
			height: 420,
		},
		rating: 5,
		name: "Amanda Johnson",
		text: "I want to thank you for your service. I can't tell you how many times it has saved my time. You have a customer for life! Thank you Pak Trolly Services! Keep the good work up",
	},
	{
		id: 5,
		avatar: {
			src: "/assets/images/testimonials/5.jpg",
			width: 420,
			height: 420,
		},
		rating: 5,
		name: "Marvel Blu",
		text: "Best User Experince ever I have. product was so good in quality and my delivery was on time. It was with an amazing Packing. Along with all customer support is good. They response timely.There were no damage or any kind of scratches.They deliverd the orderd product with care. Keep it up",
	},
	{
		id: 6,
		avatar: {
			src: "/assets/images/testimonials/2.jpg",
			width: 420,
			height: 420,
		},
		rating: 4,
		name: "Jiniya Snow",
		text: "I will recommend Pak trolly for Electronic Shopping.. I ordered laptop from the website. It was as same as in image. Packaging was so good & the best thing of this site is, my order was deliverd on time, I am very much satisfied and liked the services.",
	},
];
